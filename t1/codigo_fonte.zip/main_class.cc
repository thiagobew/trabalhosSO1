#include "main_class.h"

__BEGIN_API

CPU::Context *Main::ContextMain = 0;
CPU::Context *Main::ping = 0;
CPU::Context *Main::pong = 0;
std::string Main::ping_name;
std::string Main::pong_name;

__END_API
